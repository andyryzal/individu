<?php
// Panggil "ISI"yang di controller
if($isi) {
	$this->load->view($isi);
}